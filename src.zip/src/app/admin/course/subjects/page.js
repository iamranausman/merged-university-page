import SubjectList from '../../../admin/pages/Course/SubjectList';
import Layout from '../../components/Layout';

export default function SubjectsPage() {
  return <Layout><SubjectList /></Layout>;
}