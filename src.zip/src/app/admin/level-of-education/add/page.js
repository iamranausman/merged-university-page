'use client';
import Layout from '../../components/Layout';
import AddLevelEducation from '../../pages/LevelEducation/AddLevelEducation';
export default function AddLevelEducationPage() {
  return (
    <Layout>
      <AddLevelEducation />
    </Layout>
  );
} 