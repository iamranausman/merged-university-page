'use client';

import Layout from '../components/Layout';
import AddLevelEducation from '../pages/LevelEducation/AddLevelEducation';
import LevelEducationList from '../pages/LevelEducation/LevelEducationList';

const AddArticlePage = () => {
  return (
    <Layout>
     {/* <AddLevelEducation/> */}
     <LevelEducationList/>
    </Layout>
  );
};

export default AddArticlePage; 