"use client";

import NewDashboard from "../../../app/components/molecules/NewDashboard";

export default function DashboardPage() {
  // Default: student dashboard
  return <NewDashboard />;
}