"use client";

import ConsultantDashboard from '../../components/molecules/consultant/Dashboard';

export default function ConsultantDashboardPage() {
  // Default: student dashboard
  return <ConsultantDashboard />;
}