'use client';
import Layout from '../components/Layout';
import LevelEducationList from '../pages/LevelEducation/LevelEducationList';
export default function LevelEducationListPage() {
  return (
    <Layout>
      <LevelEducationList />
    </Layout>
  );
} 