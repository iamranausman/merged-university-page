import Notifications from '../pages/Notification/NotificationList';

export default function NotificationsPage() {
  return <Notifications />;
}