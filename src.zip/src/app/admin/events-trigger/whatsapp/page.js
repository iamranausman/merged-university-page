'use client';
import Layout from '../../components/Layout';
import WhatsAppEvents from '../../pages/EventsTrigger/WhatsAppEvents';
export default function WhatsAppEventsPage() {
  return (
    <Layout>
      <WhatsAppEvents />
    </Layout>
  );
} 