export const studentSuccessData = [
 {
   name: "Ayesha Khan",
   image: "https://randomuser.me/api/portraits/women/44.jpg",
   message:
     "Minhaj ki guidance ke bina mujhe scholarship milna mushkil tha. Ab main UK mein free education le rahi hoon!"
 },
 {
   name: "Ali Raza",
   image: "https://randomuser.me/api/portraits/men/47.jpg",
   message:
     "Visa process bht smooth raha. Mujhe har step pe support mila — highly recommended!"
 },
 {
   name: "Sara Malik",
   image: "https://randomuser.me/api/portraits/women/68.jpg",
   message:
     "IELTS training ne meri confidence bht barhayi. Mujhe Australia ka student visa easily mil gaya."
 },
 {
   name: "Usman Tariq",
   image: "https://randomuser.me/api/portraits/men/58.jpg",
   message:
     "Admission support aur timely communication ki wajah se main Canada ke top university mein pahuncha."
 },
 {
   name: "Hina Bashir",
   image: "https://randomuser.me/api/portraits/women/22.jpg",
   message:
     "Scholarship ke liye apply karna pehle mushkil lagta tha, lekin Minhaj team ne sab handle kiya."
 },
 {
   name: "Zain Ahmed",
   image: "https://randomuser.me/api/portraits/men/19.jpg",
   message:
     "Unki support system ne mujhe Europe jaane ka rasta dikhaya — life changing experience!"
 },
 {
   name: "Fatima Noor",
   image: "https://randomuser.me/api/portraits/women/90.jpg",
   message:
     "Minhaj ki help se mujhe 100% tuition fee waiver mila aur Germany mein admission confirm hua."
 },
 {
   name: "Hamza Shahid",
   image: "https://randomuser.me/api/portraits/men/31.jpg",
   message:
     "Main confuse tha kaun si country select karun. Unki expert team ne perfect guide kiya."
 }
];
